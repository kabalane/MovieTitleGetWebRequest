﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Web.Script.Serialization;
namespace MovieTitleGetWebRequest
{
    class Program
    {
        static void Main(string[] args)
        {
            string json = string.Empty;
            List<string> titleList = new List<string>();
            string url = @"https://jsonmock.hackerrank.com/api/movies/search/?Title=Spiderman";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.AutomaticDecompression = DecompressionMethods.GZip;

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                json = reader.ReadToEnd();
            }

           
            MovieData movieData = new JavaScriptSerializer().Deserialize<MovieData>(json);
            //add titles to list
            addToList(movieData, titleList);
            int numPages = Convert.ToInt32(movieData.total_pages);
            for (int i = 2; i <= numPages; i++)
            {
                url = @"https://jsonmock.hackerrank.com/api/movies/search/?Title=Spiderman&&page=" + i;
                movieData = new JavaScriptSerializer().Deserialize<MovieData>(json);
                addToList(movieData, titleList);

            }
            titleList.Sort();
            foreach (string s in titleList)
            {
                Console.WriteLine(s);
            }
                Console.Read();
        }

        private static void addToList(MovieData movieData, List<string> titleList)
        {
            if (movieData != null && movieData.data !=null)
            {
                for (int i = 0; i < movieData.data.Count(); i++)
                {
                    titleList.Add(movieData.data[i].Title);
                }
            }
        }
    }
    class MovieData
    {
        public string page
        {
            get;
            set;
        }
        public string per_page
        {
            get;
            set;
        }
        public string total
        {
            get;
            set;
        }
        public string total_pages
        {
            get;
            set;
        }
        public Data[] data
        {
            get;
            set;
        }

    }
    class Data
    {
        public string Poster
        {
            get;
            set;
        }
        public string Title
        {
            get;
            set;
        }
        public string Type
        {
            get;
            set;
        }
        public string Year
        {
            get;
            set;
        }
        public string imdbID
        {
            get;
            set;
        }  
    }
}
